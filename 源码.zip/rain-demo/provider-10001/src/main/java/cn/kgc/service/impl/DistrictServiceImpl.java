package cn.kgc.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import cn.kgc.dao.DistrictDao;
import cn.kgc.entity.District;
import cn.kgc.service.DistrictService;
import org.springframework.stereotype.Service;

/**
 * (District)表服务实现类
 *
 * @author makejava
 * @since 2020-05-11 15:23:10
 */
@Service("districtService")
public class DistrictServiceImpl extends ServiceImpl<DistrictDao, District> implements DistrictService {

}