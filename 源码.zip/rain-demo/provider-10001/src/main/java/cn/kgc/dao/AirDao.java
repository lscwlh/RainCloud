package cn.kgc.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import cn.kgc.entity.Air;

/**
 * (Air)表数据库访问层
 *
 * @author makejava
 * @since 2020-05-11 15:23:10
 */
public interface AirDao extends BaseMapper<Air> {

}