package cn.kgc.controller;


import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.api.ApiController;
import com.baomidou.mybatisplus.extension.api.R;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import cn.kgc.entity.District;
import cn.kgc.service.DistrictService;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.ws.rs.GET;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * (District)表控制层
 *
 * @author makejava
 * @since 2020-05-11 16:14:27
 */

@RestController
public class DistrictController extends ApiController {

    @Resource
    private DistrictService districtService;


    @GetMapping(value = "District", produces = {"application/json;charset=UTF-8"})
    public String selectAllDistrict(
            @RequestParam(value = "pageNum", required = false) Integer pageNum,
            @RequestParam(value = "pageSize", required = false) Integer pageSize
    ) {
        Page<District> page = new Page<>(pageNum != null ? pageNum : 1, pageSize != null ? pageSize : 1000);
        return JSON.toJSONString(districtService.page(page, new QueryWrapper<>(null)));
    }


    @GetMapping(value = "District/{id}", produces = {"application/json;charset=UTF-8"})
    public String selectOneDistrict(@PathVariable Serializable id) {
        return JSON.toJSONString(districtService.getById(id));
    }

    @PostMapping(value = "saveDistrict")
    public String insertDistrict(@RequestBody District district) {
        R r = success(this.districtService.save(district));
        return r.getMsg();
    }

    @PutMapping(value = "putDistrict")
    public String updateDistrict(@RequestBody District district) {
        R r = success(this.districtService.updateById(district));
        return r.getMsg();
    }

    @GetMapping(value = "delDistrict")
    public String deleteDistrict(@RequestParam(value = "ids", required = false) String ids) {
        if (ids != null) {
            List<Long> idList = new ArrayList<>();
            for (String s : ids.split(",")) {
                idList.add(Long.valueOf(s));
            }
            R r = success(this.districtService.removeByIds(idList));
            return r.getMsg();
        }
        return "请选择要删除的信息!";
    }
}