package cn.kgc.entity;

import java.util.Date;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;

/**
 * (Air)表实体类
 *
 * @author makejava
 * @since 2020-05-11 15:07:44
 */
@SuppressWarnings("serial")
public class Air extends Model<Air> {

    @TableId(value = "id",type = IdType.AUTO)
    private Integer id;
    
    private Integer districid;

    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date createtime;
    
    private Integer pm10;
    
    private Integer pm25;
    
    private String station;

    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date lasttime;


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getDistricid() {
        return districid;
    }

    public void setDistricid(Integer districid) {
        this.districid = districid;
    }

    public Date getCreatetime() {
        return createtime;
    }

    public void setCreatetime(Date createtime) {
        this.createtime = createtime;
    }

    public Integer getPm10() {
        return pm10;
    }

    public void setPm10(Integer pm10) {
        this.pm10 = pm10;
    }

    public Integer getPm25() {
        return pm25;
    }

    public void setPm25(Integer pm25) {
        this.pm25 = pm25;
    }

    public String getStation() {
        return station;
    }

    public void setStation(String station) {
        this.station = station;
    }

    public Date getLasttime() {
        return lasttime;
    }

    public void setLasttime(Date lasttime) {
        this.lasttime = lasttime;
    }

    /**
     * 获取主键值
     *
     * @return 主键值
     */
    @Override
    protected Serializable pkVal() {
        return this.id;
    }
    }