package cn.kgc.client;

import cn.kgc.client.impl.RainClientImpl;
import cn.kgc.entity.Air;
import cn.kgc.entity.District;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.*;

import java.io.Serializable;

@FeignClient(value = "rain-provider", fallback = RainClientImpl.class)
public interface RainClient {

    @GetMapping(value = "Air", produces = {"application/json;charset=UTF-8"})
    public String selectAllAir(
            @RequestParam(value = "pageNum", required = false) Integer pageNum,
            @RequestParam(value = "pageSize", required = false) Integer pageSize,
            @RequestParam(value = "district", required = false) Integer district
    );

    @GetMapping(value = "Air/{id}", produces = {"application/json;charset=UTF-8"})
    public String selectOneAir(@PathVariable Serializable id);

    @PostMapping(value = "saveAir")
    public String insertAir(@RequestBody Air air);

    @PutMapping(value = "putAir")
    public String updateAir(@RequestBody Air air);

    @GetMapping(value = "delAir")
    public String deleteAir(@RequestParam(value = "ids", required = false) String ids);

    @GetMapping(value = "District", produces = {"application/json;charset=UTF-8"})
    public String selectAllDistrict(
            @RequestParam(value = "pageNum", required = false) Integer pageNum,
            @RequestParam(value = "pageSize", required = false) Integer pageSize
    );

    @GetMapping(value = "District/{id}", produces = {"application/json;charset=UTF-8"})
    public String selectOneDistrict(@PathVariable Serializable id);

    @PostMapping(value = "saveDistrict")
    public String insertDistrict(@RequestBody District district);

    @PutMapping(value = "putDistrict")
    public String updateDistrict(@RequestBody District district);

    @GetMapping(value = "delDistrict")
    public String deleteDistrict(@RequestParam(value = "ids", required = false) String ids);
}
