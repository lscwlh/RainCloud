package cn.kgc.controller;

import cn.kgc.client.RainClient;
import cn.kgc.entity.Air;
import cn.kgc.entity.District;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.io.Serializable;

@RestController
public class RainController {

    @Resource
    RainClient rainClient;

    @GetMapping(value = "Air", produces = {"application/json;charset=UTF-8"})
    public String selectAllAir(Integer pageNum, Integer pageSize, Integer district) {
        return rainClient.selectAllAir(pageNum, pageSize, district);
    }

    @GetMapping(value = "Air/{id}", produces = {"application/json;charset=UTF-8"})
    public String selectOneAir(@PathVariable Serializable id) {
        return rainClient.selectOneAir(id);
    }

    @PostMapping(value = "saveAir")
    public String insertAir(Air air) {
        return rainClient.insertAir(air);
    }

    @PostMapping(value = "putAir")
    public String updateAir(Air air) {
        return rainClient.updateAir(air);
    }

    @GetMapping(value = "delAir")
    public String deleteAir(String ids) {
        return rainClient.deleteAir(ids);
    }

    @GetMapping(value = "District", produces = {"application/json;charset=UTF-8"})
    public String selectAllDistrict(Integer pageNum, Integer pageSize) {
        return rainClient.selectAllDistrict(pageNum, pageSize);
    }
}
