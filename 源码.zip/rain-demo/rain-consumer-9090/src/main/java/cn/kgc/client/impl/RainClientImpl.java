package cn.kgc.client.impl;

import cn.kgc.client.RainClient;
import cn.kgc.entity.Air;
import cn.kgc.entity.District;
import org.springframework.stereotype.Component;

import java.io.Serializable;

@Component
public class RainClientImpl implements RainClient {

    @Override
    public String selectAllAir(Integer pageNum, Integer pageSize,Integer district) {
        return null;
    }

    @Override
    public String selectOneAir(Serializable id) {
        return null;
    }

    @Override
    public String insertAir(Air air) {
        return null;
    }

    @Override
    public String updateAir(Air air) {
        return null;
    }

    @Override
    public String deleteAir(String ids) {
        return null;
    }

    @Override
    public String selectAllDistrict(Integer pageNum, Integer pageSize) {
        return null;
    }

    @Override
    public String selectOneDistrict(Serializable id) {
        return null;
    }

    @Override
    public String insertDistrict(District district) {
        return null;
    }

    @Override
    public String updateDistrict(District district) {
        return null;
    }

    @Override
    public String deleteDistrict(String ids) {
        return null;
    }
}
