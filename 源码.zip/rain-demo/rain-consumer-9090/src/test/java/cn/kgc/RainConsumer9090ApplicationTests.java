package cn.kgc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RainConsumer9090ApplicationTests {

    @Test
    void contextLoads() {
    }

}
