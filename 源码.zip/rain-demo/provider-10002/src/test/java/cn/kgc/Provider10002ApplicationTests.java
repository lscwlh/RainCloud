package cn.kgc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Provider10002ApplicationTests {

    @Test
    void contextLoads() {
    }

}
