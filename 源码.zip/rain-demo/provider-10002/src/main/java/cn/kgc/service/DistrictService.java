package cn.kgc.service;

import cn.kgc.entity.District;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * (District)表服务接口
 *
 * @author makejava
 * @since 2020-05-11 15:23:10
 */
public interface DistrictService extends IService<District> {

}