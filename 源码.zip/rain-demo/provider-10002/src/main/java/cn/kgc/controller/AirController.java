package cn.kgc.controller;


import cn.kgc.entity.Air;
import cn.kgc.service.AirService;
import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.api.ApiController;
import com.baomidou.mybatisplus.extension.api.R;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * (Air)表控制层
 *
 * @author makejava
 * @since 2020-05-11 16:14:26
 */

@RestController
public class AirController extends ApiController {

    @Resource
    private AirService airService;


    @GetMapping(value = "Air", produces = {"application/json;charset=UTF-8"})
    public String selectAllAir(
            @RequestParam(value = "pageNum", required = false) Integer pageNum,
            @RequestParam(value = "pageSize", required = false) Integer pageSize,
            @RequestParam(value = "district", required = false) Integer district
    ) {
        Page<Air> page = new Page<>(pageNum != null ? pageNum : 1, pageSize != null ? pageSize : 4);
        Air air = new Air();
        air.setDistricid(district);
        return JSON.toJSONString(airService.page(page, new QueryWrapper<>(air)));
    }


    @GetMapping(value = "Air/{id}", produces = {"application/json;charset=UTF-8"})
    public String selectOneAir(@PathVariable Serializable id) {
        return JSON.toJSONString(airService.getById(id));
    }

    @PostMapping(value = "saveAir")
    public String insertAir(@RequestBody Air air) {
        R r = success(this.airService.save(air));
        return r.getMsg();
    }

    @PutMapping(value = "putAir")
    public String updateAir(@RequestBody Air air) {
        R r = success(this.airService.updateById(air));
        return r.getMsg();
    }

    @GetMapping(value = "delAir")
    public String deleteAir(@RequestParam(value = "ids", required = false) String ids) {
        if (ids != null) {
            List<Long> idList = new ArrayList<>();
            for (String s : ids.split(",")) {
                idList.add(Long.valueOf(s));
            }
            R r = success(this.airService.removeByIds(idList));
            return r.getMsg();
        }
        return "请选择要删除的信息!";
    }
}