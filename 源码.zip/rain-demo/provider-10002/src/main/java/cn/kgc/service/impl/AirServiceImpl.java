package cn.kgc.service.impl;

import cn.kgc.dao.AirDao;
import cn.kgc.entity.Air;
import cn.kgc.service.AirService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * (Air)表服务实现类
 *
 * @author makejava
 * @since 2020-05-11 15:23:10
 */
@Service("airService")
public class AirServiceImpl extends ServiceImpl<AirDao, Air> implements AirService {

}