package cn.kgc.dao;

import cn.kgc.entity.District;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * (District)表数据库访问层
 *
 * @author makejava
 * @since 2020-05-11 15:23:10
 */
public interface DistrictDao extends BaseMapper<District> {

}