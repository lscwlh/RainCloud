package cn.kgc.service;

import cn.kgc.entity.Air;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * (Air)表服务接口
 *
 * @author makejava
 * @since 2020-05-11 15:23:10
 */
public interface AirService extends IService<Air> {

}