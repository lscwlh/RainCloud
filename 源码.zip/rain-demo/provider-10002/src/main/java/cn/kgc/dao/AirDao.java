package cn.kgc.dao;

import cn.kgc.entity.Air;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * (Air)表数据库访问层
 *
 * @author makejava
 * @since 2020-05-11 15:23:10
 */
public interface AirDao extends BaseMapper<Air> {

}